/*:
 A Simple Tomato Sauce

 This is a simple tomato sauce recipe

 You can add a title with the # sign or by underlining with = or -

 # List of ingredients

 Below is a simple unordered list, any one of the -, + • or * character will make for a new list item

 - Tomatoes
 - Garlic
 - Basil
 - Pecorino romano

 Using more than one # character let you add a sub level to your titles.

 ## From you pantry

 - Olive oil
 - Salt, pepper

 Lastly, you can create ordered list using regular numbers. You do not have to count the number, always using 1 works perfectly well

 # Recipe

 1. Cook the garlic over medium heat
 1. Once golden add the sliced tomatoes and a cup of water
 1. Bring to a boil, and reduce to a simmer
 1. Add salt, pepper, basil
 */

enum SlopeError: Error {
    case inifinite
}

/**
 Compute the slope between two points

 This function calculate the slope between two points in a carthesian plane

 - Returns:
 the slope bewteen the points (x0, y0) and (x1, y1)

 - Parameters:
    - x0: the x coordinate for the first point
    - y0: the y coordinate for the first point
    - x1: the x coordinate for the second point
    - y1: the y coordinate for the second point

 - Throws: SlopeError.infinite when y1 - y0 === 0: ie the slope is infinite

 ```
 const flat = try! slope(x0: 2, y0: 1, x1: 5, y1: 1)
 flat === 0
 ```


 The **rich** capabilities of markdown help your render text *nicely*.
 You can mention `code` inline with the single backtick.

 */
func slope(x0: Double, y0: Double, x1: Double, y1: Double) throws -> Double {
    guard x1 - x0 != 0 else {
        throw SlopeError.inifinite
    }
    return y1 - y0 / x1 - x0
}
