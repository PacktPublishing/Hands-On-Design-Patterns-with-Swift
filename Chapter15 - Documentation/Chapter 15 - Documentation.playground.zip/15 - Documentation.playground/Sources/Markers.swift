// MARK: Imports
import Foundation
import UIKit

// MARK: -

// TODO: Finish this module

func subtract(a: Int, b: Int) -> Int {
    // FIXME: I believe this is wrong
    return a + b
}

// MARK: -

func add(a: Int, b: Int) -> Int {
    return a + b
}
